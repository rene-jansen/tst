﻿define(['backbone', 'models/country'], function (Backbone, Country) {
    var Countries = Backbone.Collection.extend({
        model: Country,
        create: function (options) {
            this.push(new Country(options));
        }
    });
    return Countries;
});