﻿define(['jquery', 'underscore', 'backbone'], function ($, _, Backbone) {
    var recipeTileView = Backbone.View.extend({
        template: _.template($('#recipe-tile-template').html()),
        render: function () {
            this.$el.html(this.template(this.model.toJSON()));
            return this;
        }
    });
    return recipeTileView;
});